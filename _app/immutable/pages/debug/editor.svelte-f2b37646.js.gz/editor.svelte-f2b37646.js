import"../../chunks/index-f6cfea4e.js";import{E as p}from"../../chunks/editor-612ff22b.js";/* empty css                                                       */export{p as default};
