import"../../chunks/index-f6cfea4e.js";import{S as i}from"../../chunks/suggestion-d85da2af.js";import"../../chunks/index-ff9ff7c9.js";import"../../chunks/index-5303bb93.js";export{i as default};
