import"../../chunks/index-3a01bbf7.js";import{S as i}from"../../chunks/suggestion-7c669416.js";import"../../chunks/index-cf574cb9.js";import"../../chunks/index-5303bb93.js";export{i as default};
