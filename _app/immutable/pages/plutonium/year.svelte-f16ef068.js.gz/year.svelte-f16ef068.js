import"../../chunks/index-f6cfea4e.js";import{Y as a}from"../../chunks/year-97040d48.js";export{a as default};
