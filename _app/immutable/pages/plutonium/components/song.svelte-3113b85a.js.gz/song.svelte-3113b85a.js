import{S as t,i as e,s as n}from"../../../chunks/index-3a01bbf7.js";class l extends t{constructor(s){super(),e(this,s,null,null,n,{})}}export{l as default};
