import"../../chunks/index-a063a824.js";import{E as p}from"../../chunks/editor-08285703.js";/* empty css                                                       */export{p as default};
