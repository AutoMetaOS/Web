import"../../chunks/index-ef3d5a38.js";import{E as p}from"../../chunks/editor-6731bef1.js";/* empty css                                                       */export{p as default};
