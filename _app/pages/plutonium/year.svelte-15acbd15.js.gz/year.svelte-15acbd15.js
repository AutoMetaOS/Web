import"../../chunks/index-132e5a0e.js";import{Y as a}from"../../chunks/year-7c7c9829.js";export{a as default};
