import{S as t,i as e,s as n}from"../../../chunks/index-ef3d5a38.js";class l extends t{constructor(s){super(),e(this,s,null,null,n,{})}}export{l as default};
