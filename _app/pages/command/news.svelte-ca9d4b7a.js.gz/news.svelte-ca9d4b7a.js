import"../../chunks/index-ef3d5a38.js";import{N as a}from"../../chunks/news-233f9658.js";export{a as default};
