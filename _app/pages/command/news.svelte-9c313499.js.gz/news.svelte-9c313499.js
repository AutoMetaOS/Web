import"../../chunks/index-a063a824.js";import{N as a}from"../../chunks/news-d3b6ac28.js";export{a as default};
