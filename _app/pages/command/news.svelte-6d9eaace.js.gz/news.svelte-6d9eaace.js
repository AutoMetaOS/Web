import"../../chunks/index-132e5a0e.js";import{N as a}from"../../chunks/news-46cffda8.js";export{a as default};
