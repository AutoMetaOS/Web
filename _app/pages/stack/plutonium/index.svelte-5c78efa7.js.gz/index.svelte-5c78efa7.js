import{S as t,i as e,s as l}from"../../../chunks/index-a063a824.js";class a extends t{constructor(s){super(),e(this,s,null,null,l,{})}}export{a as default};
