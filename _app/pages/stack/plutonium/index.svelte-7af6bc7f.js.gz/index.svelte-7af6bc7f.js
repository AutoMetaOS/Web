import{S as t,i as e,s as l}from"../../../chunks/index-ef3d5a38.js";class a extends t{constructor(s){super(),e(this,s,null,null,l,{})}}export{a as default};
