import{S as t,i as e,s as o}from"../../../chunks/index-132e5a0e.js";class n extends t{constructor(s){super(),e(this,s,null,null,o,{})}}export{n as default};
