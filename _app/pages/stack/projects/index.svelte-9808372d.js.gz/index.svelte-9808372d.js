import{S as t,i as e,s as o}from"../../../chunks/index-ef3d5a38.js";class n extends t{constructor(s){super(),e(this,s,null,null,o,{})}}export{n as default};
