"use strict";

localStorage.setItem( "amos_master_hash", 'c3f438ce714c766ab764fe2f96a8e6ce7216dc4ed26572e160b2156f54a7ef20' );